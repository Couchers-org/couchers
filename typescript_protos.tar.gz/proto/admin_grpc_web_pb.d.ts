import * as grpcWeb from 'grpc-web';

import * as admin_pb from './admin_pb';
import * as communities_pb from './communities_pb';


export class AdminClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getUserDetails(
    request: admin_pb.GetUserDetailsReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.UserDetails) => void
  ): grpcWeb.ClientReadableStream<admin_pb.UserDetails>;

  changeUserGender(
    request: admin_pb.ChangeUserGenderReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.UserDetails) => void
  ): grpcWeb.ClientReadableStream<admin_pb.UserDetails>;

  changeUserBirthdate(
    request: admin_pb.ChangeUserBirthdateReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.UserDetails) => void
  ): grpcWeb.ClientReadableStream<admin_pb.UserDetails>;

  banUser(
    request: admin_pb.BanUserReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.UserDetails) => void
  ): grpcWeb.ClientReadableStream<admin_pb.UserDetails>;

  deleteUser(
    request: admin_pb.DeleteUserReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.UserDetails) => void
  ): grpcWeb.ClientReadableStream<admin_pb.UserDetails>;

  recoverDeletedUser(
    request: admin_pb.RecoverDeletedUserReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.UserDetails) => void
  ): grpcWeb.ClientReadableStream<admin_pb.UserDetails>;

  createApiKey(
    request: admin_pb.CreateApiKeyReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.CreateApiKeyRes) => void
  ): grpcWeb.ClientReadableStream<admin_pb.CreateApiKeyRes>;

  createCommunity(
    request: admin_pb.CreateCommunityReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: communities_pb.Community) => void
  ): grpcWeb.ClientReadableStream<communities_pb.Community>;

  getChats(
    request: admin_pb.GetChatsReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: admin_pb.GetChatsRes) => void
  ): grpcWeb.ClientReadableStream<admin_pb.GetChatsRes>;

}

export class AdminPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getUserDetails(
    request: admin_pb.GetUserDetailsReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.UserDetails>;

  changeUserGender(
    request: admin_pb.ChangeUserGenderReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.UserDetails>;

  changeUserBirthdate(
    request: admin_pb.ChangeUserBirthdateReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.UserDetails>;

  banUser(
    request: admin_pb.BanUserReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.UserDetails>;

  deleteUser(
    request: admin_pb.DeleteUserReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.UserDetails>;

  recoverDeletedUser(
    request: admin_pb.RecoverDeletedUserReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.UserDetails>;

  createApiKey(
    request: admin_pb.CreateApiKeyReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.CreateApiKeyRes>;

  createCommunity(
    request: admin_pb.CreateCommunityReq,
    metadata?: grpcWeb.Metadata
  ): Promise<communities_pb.Community>;

  getChats(
    request: admin_pb.GetChatsReq,
    metadata?: grpcWeb.Metadata
  ): Promise<admin_pb.GetChatsRes>;

}


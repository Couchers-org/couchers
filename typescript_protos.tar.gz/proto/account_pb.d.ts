import * as jspb from 'google-protobuf'

import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb';
import * as google_protobuf_wrappers_pb from 'google-protobuf/google/protobuf/wrappers_pb';
import * as annotations_pb from './annotations_pb';
import * as auth_pb from './auth_pb';


export class GetAccountInfoRes extends jspb.Message {
  getLoginMethod(): GetAccountInfoRes.LoginMethod;
  setLoginMethod(value: GetAccountInfoRes.LoginMethod): GetAccountInfoRes;

  getHasPassword(): boolean;
  setHasPassword(value: boolean): GetAccountInfoRes;

  getUsername(): string;
  setUsername(value: string): GetAccountInfoRes;

  getEmail(): string;
  setEmail(value: string): GetAccountInfoRes;

  getProfileComplete(): boolean;
  setProfileComplete(value: boolean): GetAccountInfoRes;

  getPhone(): string;
  setPhone(value: string): GetAccountInfoRes;

  getPhoneVerified(): boolean;
  setPhoneVerified(value: boolean): GetAccountInfoRes;

  getTimezone(): string;
  setTimezone(value: string): GetAccountInfoRes;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetAccountInfoRes.AsObject;
  static toObject(includeInstance: boolean, msg: GetAccountInfoRes): GetAccountInfoRes.AsObject;
  static serializeBinaryToWriter(message: GetAccountInfoRes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetAccountInfoRes;
  static deserializeBinaryFromReader(message: GetAccountInfoRes, reader: jspb.BinaryReader): GetAccountInfoRes;
}

export namespace GetAccountInfoRes {
  export type AsObject = {
    loginMethod: GetAccountInfoRes.LoginMethod,
    hasPassword: boolean,
    username: string,
    email: string,
    profileComplete: boolean,
    phone: string,
    phoneVerified: boolean,
    timezone: string,
  }

  export enum LoginMethod { 
    MAGIC_LINK = 0,
    PASSWORD = 1,
  }
}

export class ChangePasswordReq extends jspb.Message {
  getOldPassword(): google_protobuf_wrappers_pb.StringValue | undefined;
  setOldPassword(value?: google_protobuf_wrappers_pb.StringValue): ChangePasswordReq;
  hasOldPassword(): boolean;
  clearOldPassword(): ChangePasswordReq;

  getNewPassword(): google_protobuf_wrappers_pb.StringValue | undefined;
  setNewPassword(value?: google_protobuf_wrappers_pb.StringValue): ChangePasswordReq;
  hasNewPassword(): boolean;
  clearNewPassword(): ChangePasswordReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangePasswordReq.AsObject;
  static toObject(includeInstance: boolean, msg: ChangePasswordReq): ChangePasswordReq.AsObject;
  static serializeBinaryToWriter(message: ChangePasswordReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangePasswordReq;
  static deserializeBinaryFromReader(message: ChangePasswordReq, reader: jspb.BinaryReader): ChangePasswordReq;
}

export namespace ChangePasswordReq {
  export type AsObject = {
    oldPassword?: google_protobuf_wrappers_pb.StringValue.AsObject,
    newPassword?: google_protobuf_wrappers_pb.StringValue.AsObject,
  }
}

export class ChangeEmailReq extends jspb.Message {
  getPassword(): google_protobuf_wrappers_pb.StringValue | undefined;
  setPassword(value?: google_protobuf_wrappers_pb.StringValue): ChangeEmailReq;
  hasPassword(): boolean;
  clearPassword(): ChangeEmailReq;

  getNewEmail(): string;
  setNewEmail(value: string): ChangeEmailReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangeEmailReq.AsObject;
  static toObject(includeInstance: boolean, msg: ChangeEmailReq): ChangeEmailReq.AsObject;
  static serializeBinaryToWriter(message: ChangeEmailReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangeEmailReq;
  static deserializeBinaryFromReader(message: ChangeEmailReq, reader: jspb.BinaryReader): ChangeEmailReq;
}

export namespace ChangeEmailReq {
  export type AsObject = {
    password?: google_protobuf_wrappers_pb.StringValue.AsObject,
    newEmail: string,
  }
}

export class GetContributorFormInfoRes extends jspb.Message {
  getFilledContributorForm(): boolean;
  setFilledContributorForm(value: boolean): GetContributorFormInfoRes;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetContributorFormInfoRes.AsObject;
  static toObject(includeInstance: boolean, msg: GetContributorFormInfoRes): GetContributorFormInfoRes.AsObject;
  static serializeBinaryToWriter(message: GetContributorFormInfoRes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetContributorFormInfoRes;
  static deserializeBinaryFromReader(message: GetContributorFormInfoRes, reader: jspb.BinaryReader): GetContributorFormInfoRes;
}

export namespace GetContributorFormInfoRes {
  export type AsObject = {
    filledContributorForm: boolean,
  }
}

export class FillContributorFormReq extends jspb.Message {
  getContributorForm(): auth_pb.ContributorForm | undefined;
  setContributorForm(value?: auth_pb.ContributorForm): FillContributorFormReq;
  hasContributorForm(): boolean;
  clearContributorForm(): FillContributorFormReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FillContributorFormReq.AsObject;
  static toObject(includeInstance: boolean, msg: FillContributorFormReq): FillContributorFormReq.AsObject;
  static serializeBinaryToWriter(message: FillContributorFormReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FillContributorFormReq;
  static deserializeBinaryFromReader(message: FillContributorFormReq, reader: jspb.BinaryReader): FillContributorFormReq;
}

export namespace FillContributorFormReq {
  export type AsObject = {
    contributorForm?: auth_pb.ContributorForm.AsObject,
  }
}

export class ChangePhoneReq extends jspb.Message {
  getPhone(): string;
  setPhone(value: string): ChangePhoneReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangePhoneReq.AsObject;
  static toObject(includeInstance: boolean, msg: ChangePhoneReq): ChangePhoneReq.AsObject;
  static serializeBinaryToWriter(message: ChangePhoneReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangePhoneReq;
  static deserializeBinaryFromReader(message: ChangePhoneReq, reader: jspb.BinaryReader): ChangePhoneReq;
}

export namespace ChangePhoneReq {
  export type AsObject = {
    phone: string,
  }
}

export class VerifyPhoneReq extends jspb.Message {
  getToken(): string;
  setToken(value: string): VerifyPhoneReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VerifyPhoneReq.AsObject;
  static toObject(includeInstance: boolean, msg: VerifyPhoneReq): VerifyPhoneReq.AsObject;
  static serializeBinaryToWriter(message: VerifyPhoneReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VerifyPhoneReq;
  static deserializeBinaryFromReader(message: VerifyPhoneReq, reader: jspb.BinaryReader): VerifyPhoneReq;
}

export namespace VerifyPhoneReq {
  export type AsObject = {
    token: string,
  }
}

export class DeleteAccountReq extends jspb.Message {
  getConfirm(): boolean;
  setConfirm(value: boolean): DeleteAccountReq;

  getReason(): string;
  setReason(value: string): DeleteAccountReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteAccountReq.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteAccountReq): DeleteAccountReq.AsObject;
  static serializeBinaryToWriter(message: DeleteAccountReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteAccountReq;
  static deserializeBinaryFromReader(message: DeleteAccountReq, reader: jspb.BinaryReader): DeleteAccountReq;
}

export namespace DeleteAccountReq {
  export type AsObject = {
    confirm: boolean,
    reason: string,
  }
}


import * as jspb from 'google-protobuf'

import * as annotations_pb from './annotations_pb';
import * as communities_pb from './communities_pb';


export class UserDetails extends jspb.Message {
  getUserId(): number;
  setUserId(value: number): UserDetails;

  getUsername(): string;
  setUsername(value: string): UserDetails;

  getEmail(): string;
  setEmail(value: string): UserDetails;

  getGender(): string;
  setGender(value: string): UserDetails;

  getBirthdate(): string;
  setBirthdate(value: string): UserDetails;

  getBanned(): boolean;
  setBanned(value: boolean): UserDetails;

  getDeleted(): boolean;
  setDeleted(value: boolean): UserDetails;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UserDetails.AsObject;
  static toObject(includeInstance: boolean, msg: UserDetails): UserDetails.AsObject;
  static serializeBinaryToWriter(message: UserDetails, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UserDetails;
  static deserializeBinaryFromReader(message: UserDetails, reader: jspb.BinaryReader): UserDetails;
}

export namespace UserDetails {
  export type AsObject = {
    userId: number,
    username: string,
    email: string,
    gender: string,
    birthdate: string,
    banned: boolean,
    deleted: boolean,
  }
}

export class GetUserDetailsReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): GetUserDetailsReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetUserDetailsReq.AsObject;
  static toObject(includeInstance: boolean, msg: GetUserDetailsReq): GetUserDetailsReq.AsObject;
  static serializeBinaryToWriter(message: GetUserDetailsReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetUserDetailsReq;
  static deserializeBinaryFromReader(message: GetUserDetailsReq, reader: jspb.BinaryReader): GetUserDetailsReq;
}

export namespace GetUserDetailsReq {
  export type AsObject = {
    user: string,
  }
}

export class ChangeUserGenderReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): ChangeUserGenderReq;

  getGender(): string;
  setGender(value: string): ChangeUserGenderReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangeUserGenderReq.AsObject;
  static toObject(includeInstance: boolean, msg: ChangeUserGenderReq): ChangeUserGenderReq.AsObject;
  static serializeBinaryToWriter(message: ChangeUserGenderReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangeUserGenderReq;
  static deserializeBinaryFromReader(message: ChangeUserGenderReq, reader: jspb.BinaryReader): ChangeUserGenderReq;
}

export namespace ChangeUserGenderReq {
  export type AsObject = {
    user: string,
    gender: string,
  }
}

export class ChangeUserBirthdateReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): ChangeUserBirthdateReq;

  getBirthdate(): string;
  setBirthdate(value: string): ChangeUserBirthdateReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangeUserBirthdateReq.AsObject;
  static toObject(includeInstance: boolean, msg: ChangeUserBirthdateReq): ChangeUserBirthdateReq.AsObject;
  static serializeBinaryToWriter(message: ChangeUserBirthdateReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangeUserBirthdateReq;
  static deserializeBinaryFromReader(message: ChangeUserBirthdateReq, reader: jspb.BinaryReader): ChangeUserBirthdateReq;
}

export namespace ChangeUserBirthdateReq {
  export type AsObject = {
    user: string,
    birthdate: string,
  }
}

export class BanUserReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): BanUserReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BanUserReq.AsObject;
  static toObject(includeInstance: boolean, msg: BanUserReq): BanUserReq.AsObject;
  static serializeBinaryToWriter(message: BanUserReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BanUserReq;
  static deserializeBinaryFromReader(message: BanUserReq, reader: jspb.BinaryReader): BanUserReq;
}

export namespace BanUserReq {
  export type AsObject = {
    user: string,
  }
}

export class DeleteUserReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): DeleteUserReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteUserReq.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteUserReq): DeleteUserReq.AsObject;
  static serializeBinaryToWriter(message: DeleteUserReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteUserReq;
  static deserializeBinaryFromReader(message: DeleteUserReq, reader: jspb.BinaryReader): DeleteUserReq;
}

export namespace DeleteUserReq {
  export type AsObject = {
    user: string,
  }
}

export class RecoverDeletedUserReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): RecoverDeletedUserReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RecoverDeletedUserReq.AsObject;
  static toObject(includeInstance: boolean, msg: RecoverDeletedUserReq): RecoverDeletedUserReq.AsObject;
  static serializeBinaryToWriter(message: RecoverDeletedUserReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RecoverDeletedUserReq;
  static deserializeBinaryFromReader(message: RecoverDeletedUserReq, reader: jspb.BinaryReader): RecoverDeletedUserReq;
}

export namespace RecoverDeletedUserReq {
  export type AsObject = {
    user: string,
  }
}

export class CreateApiKeyReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): CreateApiKeyReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateApiKeyReq.AsObject;
  static toObject(includeInstance: boolean, msg: CreateApiKeyReq): CreateApiKeyReq.AsObject;
  static serializeBinaryToWriter(message: CreateApiKeyReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateApiKeyReq;
  static deserializeBinaryFromReader(message: CreateApiKeyReq, reader: jspb.BinaryReader): CreateApiKeyReq;
}

export namespace CreateApiKeyReq {
  export type AsObject = {
    user: string,
  }
}

export class CreateApiKeyRes extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateApiKeyRes.AsObject;
  static toObject(includeInstance: boolean, msg: CreateApiKeyRes): CreateApiKeyRes.AsObject;
  static serializeBinaryToWriter(message: CreateApiKeyRes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateApiKeyRes;
  static deserializeBinaryFromReader(message: CreateApiKeyRes, reader: jspb.BinaryReader): CreateApiKeyRes;
}

export namespace CreateApiKeyRes {
  export type AsObject = {
  }
}

export class CreateCommunityReq extends jspb.Message {
  getName(): string;
  setName(value: string): CreateCommunityReq;

  getSlug(): string;
  setSlug(value: string): CreateCommunityReq;

  getDescription(): string;
  setDescription(value: string): CreateCommunityReq;

  getParentNodeId(): number;
  setParentNodeId(value: number): CreateCommunityReq;

  getAdminIdsList(): Array<number>;
  setAdminIdsList(value: Array<number>): CreateCommunityReq;
  clearAdminIdsList(): CreateCommunityReq;
  addAdminIds(value: number, index?: number): CreateCommunityReq;

  getGeojson(): string;
  setGeojson(value: string): CreateCommunityReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateCommunityReq.AsObject;
  static toObject(includeInstance: boolean, msg: CreateCommunityReq): CreateCommunityReq.AsObject;
  static serializeBinaryToWriter(message: CreateCommunityReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateCommunityReq;
  static deserializeBinaryFromReader(message: CreateCommunityReq, reader: jspb.BinaryReader): CreateCommunityReq;
}

export namespace CreateCommunityReq {
  export type AsObject = {
    name: string,
    slug: string,
    description: string,
    parentNodeId: number,
    adminIdsList: Array<number>,
    geojson: string,
  }
}

export class GetChatsReq extends jspb.Message {
  getUser(): string;
  setUser(value: string): GetChatsReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetChatsReq.AsObject;
  static toObject(includeInstance: boolean, msg: GetChatsReq): GetChatsReq.AsObject;
  static serializeBinaryToWriter(message: GetChatsReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetChatsReq;
  static deserializeBinaryFromReader(message: GetChatsReq, reader: jspb.BinaryReader): GetChatsReq;
}

export namespace GetChatsReq {
  export type AsObject = {
    user: string,
  }
}

export class GetChatsRes extends jspb.Message {
  getResponse(): string;
  setResponse(value: string): GetChatsRes;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetChatsRes.AsObject;
  static toObject(includeInstance: boolean, msg: GetChatsRes): GetChatsRes.AsObject;
  static serializeBinaryToWriter(message: GetChatsRes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetChatsRes;
  static deserializeBinaryFromReader(message: GetChatsRes, reader: jspb.BinaryReader): GetChatsRes;
}

export namespace GetChatsRes {
  export type AsObject = {
    response: string,
  }
}


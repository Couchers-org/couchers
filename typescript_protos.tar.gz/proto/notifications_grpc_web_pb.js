/**
 * @fileoverview gRPC-Web generated client stub for org.couchers.notifications
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var annotations_pb = require('./annotations_pb.js')
const proto = {};
proto.org = {};
proto.org.couchers = {};
proto.org.couchers.notifications = require('./notifications_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?grpc.web.ClientOptions} options
 * @constructor
 * @struct
 * @final
 */
proto.org.couchers.notifications.NotificationsClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options.format = 'binary';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?grpc.web.ClientOptions} options
 * @constructor
 * @struct
 * @final
 */
proto.org.couchers.notifications.NotificationsPromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options.format = 'binary';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.org.couchers.notifications.GetNotificationSettingsReq,
 *   !proto.org.couchers.notifications.GetNotificationSettingsRes>}
 */
const methodDescriptor_Notifications_GetNotificationSettings = new grpc.web.MethodDescriptor(
  '/org.couchers.notifications.Notifications/GetNotificationSettings',
  grpc.web.MethodType.UNARY,
  proto.org.couchers.notifications.GetNotificationSettingsReq,
  proto.org.couchers.notifications.GetNotificationSettingsRes,
  /**
   * @param {!proto.org.couchers.notifications.GetNotificationSettingsReq} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.org.couchers.notifications.GetNotificationSettingsRes.deserializeBinary
);


/**
 * @param {!proto.org.couchers.notifications.GetNotificationSettingsReq} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.RpcError, ?proto.org.couchers.notifications.GetNotificationSettingsRes)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.org.couchers.notifications.GetNotificationSettingsRes>|undefined}
 *     The XHR Node Readable Stream
 */
proto.org.couchers.notifications.NotificationsClient.prototype.getNotificationSettings =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/org.couchers.notifications.Notifications/GetNotificationSettings',
      request,
      metadata || {},
      methodDescriptor_Notifications_GetNotificationSettings,
      callback);
};


/**
 * @param {!proto.org.couchers.notifications.GetNotificationSettingsReq} request The
 *     request proto
 * @param {?Object<string, string>=} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.org.couchers.notifications.GetNotificationSettingsRes>}
 *     Promise that resolves to the response
 */
proto.org.couchers.notifications.NotificationsPromiseClient.prototype.getNotificationSettings =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/org.couchers.notifications.Notifications/GetNotificationSettings',
      request,
      metadata || {},
      methodDescriptor_Notifications_GetNotificationSettings);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.org.couchers.notifications.SetNotificationSettingsReq,
 *   !proto.org.couchers.notifications.SetNotificationSettingsRes>}
 */
const methodDescriptor_Notifications_SetNotificationSettings = new grpc.web.MethodDescriptor(
  '/org.couchers.notifications.Notifications/SetNotificationSettings',
  grpc.web.MethodType.UNARY,
  proto.org.couchers.notifications.SetNotificationSettingsReq,
  proto.org.couchers.notifications.SetNotificationSettingsRes,
  /**
   * @param {!proto.org.couchers.notifications.SetNotificationSettingsReq} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.org.couchers.notifications.SetNotificationSettingsRes.deserializeBinary
);


/**
 * @param {!proto.org.couchers.notifications.SetNotificationSettingsReq} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.RpcError, ?proto.org.couchers.notifications.SetNotificationSettingsRes)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.org.couchers.notifications.SetNotificationSettingsRes>|undefined}
 *     The XHR Node Readable Stream
 */
proto.org.couchers.notifications.NotificationsClient.prototype.setNotificationSettings =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/org.couchers.notifications.Notifications/SetNotificationSettings',
      request,
      metadata || {},
      methodDescriptor_Notifications_SetNotificationSettings,
      callback);
};


/**
 * @param {!proto.org.couchers.notifications.SetNotificationSettingsReq} request The
 *     request proto
 * @param {?Object<string, string>=} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.org.couchers.notifications.SetNotificationSettingsRes>}
 *     Promise that resolves to the response
 */
proto.org.couchers.notifications.NotificationsPromiseClient.prototype.setNotificationSettings =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/org.couchers.notifications.Notifications/SetNotificationSettings',
      request,
      metadata || {},
      methodDescriptor_Notifications_SetNotificationSettings);
};


module.exports = proto.org.couchers.notifications;


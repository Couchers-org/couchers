import * as grpcWeb from 'grpc-web';

import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb';
import * as auth_pb from './auth_pb';


export class AuthClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  signupFlow(
    request: auth_pb.SignupFlowReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.SignupFlowRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.SignupFlowRes>;

  usernameValid(
    request: auth_pb.UsernameValidReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.UsernameValidRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.UsernameValidRes>;

  login(
    request: auth_pb.LoginReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.LoginRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.LoginRes>;

  completeTokenLogin(
    request: auth_pb.CompleteTokenLoginReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.AuthRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.AuthRes>;

  authenticate(
    request: auth_pb.AuthReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.AuthRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.AuthRes>;

  deauthenticate(
    request: google_protobuf_empty_pb.Empty,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

  resetPassword(
    request: auth_pb.ResetPasswordReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

  completePasswordReset(
    request: auth_pb.CompletePasswordResetReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

  confirmChangeEmail(
    request: auth_pb.ConfirmChangeEmailReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.ConfirmChangeEmailRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.ConfirmChangeEmailRes>;

  confirmDeleteAccount(
    request: auth_pb.ConfirmDeleteAccountReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

  recoverAccount(
    request: auth_pb.RecoverAccountReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

  unsubscribe(
    request: auth_pb.UnsubscribeReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: auth_pb.UnsubscribeRes) => void
  ): grpcWeb.ClientReadableStream<auth_pb.UnsubscribeRes>;

}

export class AuthPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  signupFlow(
    request: auth_pb.SignupFlowReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.SignupFlowRes>;

  usernameValid(
    request: auth_pb.UsernameValidReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.UsernameValidRes>;

  login(
    request: auth_pb.LoginReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.LoginRes>;

  completeTokenLogin(
    request: auth_pb.CompleteTokenLoginReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.AuthRes>;

  authenticate(
    request: auth_pb.AuthReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.AuthRes>;

  deauthenticate(
    request: google_protobuf_empty_pb.Empty,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

  resetPassword(
    request: auth_pb.ResetPasswordReq,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

  completePasswordReset(
    request: auth_pb.CompletePasswordResetReq,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

  confirmChangeEmail(
    request: auth_pb.ConfirmChangeEmailReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.ConfirmChangeEmailRes>;

  confirmDeleteAccount(
    request: auth_pb.ConfirmDeleteAccountReq,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

  recoverAccount(
    request: auth_pb.RecoverAccountReq,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

  unsubscribe(
    request: auth_pb.UnsubscribeReq,
    metadata?: grpcWeb.Metadata
  ): Promise<auth_pb.UnsubscribeRes>;

}


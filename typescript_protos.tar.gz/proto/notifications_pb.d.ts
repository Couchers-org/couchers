import * as jspb from 'google-protobuf'

import * as annotations_pb from './annotations_pb';


export class GetNotificationSettingsReq extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetNotificationSettingsReq.AsObject;
  static toObject(includeInstance: boolean, msg: GetNotificationSettingsReq): GetNotificationSettingsReq.AsObject;
  static serializeBinaryToWriter(message: GetNotificationSettingsReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetNotificationSettingsReq;
  static deserializeBinaryFromReader(message: GetNotificationSettingsReq, reader: jspb.BinaryReader): GetNotificationSettingsReq;
}

export namespace GetNotificationSettingsReq {
  export type AsObject = {
  }
}

export class GetNotificationSettingsRes extends jspb.Message {
  getNewNotificationsEnabled(): boolean;
  setNewNotificationsEnabled(value: boolean): GetNotificationSettingsRes;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetNotificationSettingsRes.AsObject;
  static toObject(includeInstance: boolean, msg: GetNotificationSettingsRes): GetNotificationSettingsRes.AsObject;
  static serializeBinaryToWriter(message: GetNotificationSettingsRes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetNotificationSettingsRes;
  static deserializeBinaryFromReader(message: GetNotificationSettingsRes, reader: jspb.BinaryReader): GetNotificationSettingsRes;
}

export namespace GetNotificationSettingsRes {
  export type AsObject = {
    newNotificationsEnabled: boolean,
  }
}

export class SetNotificationSettingsReq extends jspb.Message {
  getEnableNewNotifications(): boolean;
  setEnableNewNotifications(value: boolean): SetNotificationSettingsReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SetNotificationSettingsReq.AsObject;
  static toObject(includeInstance: boolean, msg: SetNotificationSettingsReq): SetNotificationSettingsReq.AsObject;
  static serializeBinaryToWriter(message: SetNotificationSettingsReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SetNotificationSettingsReq;
  static deserializeBinaryFromReader(message: SetNotificationSettingsReq, reader: jspb.BinaryReader): SetNotificationSettingsReq;
}

export namespace SetNotificationSettingsReq {
  export type AsObject = {
    enableNewNotifications: boolean,
  }
}

export class SetNotificationSettingsRes extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SetNotificationSettingsRes.AsObject;
  static toObject(includeInstance: boolean, msg: SetNotificationSettingsRes): SetNotificationSettingsRes.AsObject;
  static serializeBinaryToWriter(message: SetNotificationSettingsRes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SetNotificationSettingsRes;
  static deserializeBinaryFromReader(message: SetNotificationSettingsRes, reader: jspb.BinaryReader): SetNotificationSettingsRes;
}

export namespace SetNotificationSettingsRes {
  export type AsObject = {
  }
}


import * as grpcWeb from 'grpc-web';

import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb';
import * as bugs_pb from './bugs_pb';


export class BugsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  version(
    request: google_protobuf_empty_pb.Empty,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: bugs_pb.VersionInfo) => void
  ): grpcWeb.ClientReadableStream<bugs_pb.VersionInfo>;

  reportBug(
    request: bugs_pb.ReportBugReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: bugs_pb.ReportBugRes) => void
  ): grpcWeb.ClientReadableStream<bugs_pb.ReportBugRes>;

}

export class BugsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  version(
    request: google_protobuf_empty_pb.Empty,
    metadata?: grpcWeb.Metadata
  ): Promise<bugs_pb.VersionInfo>;

  reportBug(
    request: bugs_pb.ReportBugReq,
    metadata?: grpcWeb.Metadata
  ): Promise<bugs_pb.ReportBugRes>;

}


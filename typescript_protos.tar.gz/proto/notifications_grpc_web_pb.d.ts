import * as grpcWeb from 'grpc-web';

import * as notifications_pb from './notifications_pb';


export class NotificationsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getNotificationSettings(
    request: notifications_pb.GetNotificationSettingsReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: notifications_pb.GetNotificationSettingsRes) => void
  ): grpcWeb.ClientReadableStream<notifications_pb.GetNotificationSettingsRes>;

  setNotificationSettings(
    request: notifications_pb.SetNotificationSettingsReq,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: notifications_pb.SetNotificationSettingsRes) => void
  ): grpcWeb.ClientReadableStream<notifications_pb.SetNotificationSettingsRes>;

}

export class NotificationsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getNotificationSettings(
    request: notifications_pb.GetNotificationSettingsReq,
    metadata?: grpcWeb.Metadata
  ): Promise<notifications_pb.GetNotificationSettingsRes>;

  setNotificationSettings(
    request: notifications_pb.SetNotificationSettingsReq,
    metadata?: grpcWeb.Metadata
  ): Promise<notifications_pb.SetNotificationSettingsRes>;

}

